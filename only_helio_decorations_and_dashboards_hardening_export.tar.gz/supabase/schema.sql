-- ==========================================
-- ONLY HELIO - DATABASE SCHEMA & ERD
-- ==========================================
-- ERD Summary:
-- partners (1) <--- (N) projects
-- partners (1) <--- (N) properties
-- projects (1) <--- (N) properties
-- partners (1) <--- (N) portfolio_items
-- requests (1) <--- (N) request_messages
-- partners (1) <--- (N) notifications
-- partners (1) <--- (N) transactions
-- property_types, finishing_statuses, amenities (Lookup tables)

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
CREATE TYPE public.partner_role AS ENUM (
    'super_admin', 'developer_partner', 'finishing_partner', 'agency_partner',
    'decoration_manager', 'platform_finishing_manager', 'finishing_market_manager',
    'platform_real_estate_manager', 'real_estate_market_manager', 'partner_relations_manager',
    'content_manager', 'service_manager', 'customer_relations_manager', 'listings_manager'
);

CREATE TYPE public.partner_status AS ENUM ('active', 'pending', 'disabled', 'rejected', 'approved');
CREATE TYPE public.listing_status AS ENUM ('active', 'inactive', 'draft', 'sold');
CREATE TYPE public.request_type AS ENUM ('PARTNER_APPLICATION', 'PROPERTY_LISTING_REQUEST', 'LEAD', 'CONTACT_MESSAGE', 'PROPERTY_INQUIRY');

-- 3. TABLES

-- Lookup: Property Types
CREATE TABLE IF NOT EXISTS public.property_types (
    id TEXT PRIMARY KEY,
    name_en TEXT NOT NULL,
    name_ar TEXT NOT NULL
);

-- Lookup: Finishing Statuses
CREATE TABLE IF NOT EXISTS public.finishing_statuses (
    id TEXT PRIMARY KEY,
    name_en TEXT NOT NULL,
    name_ar TEXT NOT NULL,
    applicable_to TEXT[] DEFAULT '{}'
);

-- Lookup: Amenities
CREATE TABLE IF NOT EXISTS public.amenities (
    id TEXT PRIMARY KEY,
    name_en TEXT NOT NULL,
    name_ar TEXT NOT NULL,
    applicable_to TEXT[] DEFAULT '{}'
);

-- Main: Partners (Profiles)
CREATE TABLE IF NOT EXISTS public.partners (
    id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    name_en TEXT NOT NULL,
    name_ar TEXT,
    description_en TEXT,
    description_ar TEXT,
    image_url TEXT,
    type TEXT NOT NULL DEFAULT 'agency', -- Matches frontend PartnerType
    role partner_role DEFAULT 'agency_partner',
    status partner_status DEFAULT 'pending',
    subscription_plan TEXT DEFAULT 'basic',
    subscription_end_date TIMESTAMPTZ,
    display_type TEXT DEFAULT 'standard',
    contact_methods JSONB DEFAULT '{"whatsapp": {"enabled": false, "number": ""}, "phone": {"enabled": false, "number": ""}, "form": {"enabled": true}}',
    parent_id UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    custom_permissions TEXT[],
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Projects (Developers only)
CREATE TABLE IF NOT EXISTS public.projects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL,
    name_en TEXT NOT NULL,
    name_ar TEXT NOT NULL,
    description_en TEXT,
    description_ar TEXT,
    image_url TEXT,
    features JSONB DEFAULT '[]', -- [{icon: string, text: {ar: string, en: string}}]
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Properties
CREATE TABLE IF NOT EXISTS public.properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL,
    project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
    title_en TEXT NOT NULL,
    title_ar TEXT NOT NULL,
    description_en TEXT,
    description_ar TEXT,
    address_en TEXT,
    address_ar TEXT,
    main_image TEXT,
    gallery TEXT[] DEFAULT '{}',
    status TEXT NOT NULL, -- 'For Sale', 'For Rent'
    type TEXT NOT NULL, -- Matches property_types.id
    price NUMERIC NOT NULL,
    area NUMERIC NOT NULL,
    beds INTEGER DEFAULT 0,
    baths INTEGER DEFAULT 0,
    floor INTEGER,
    finishing_status TEXT, -- Matches finishing_statuses.id
    amenities JSONB DEFAULT '{"en": [], "ar": []}',
    location JSONB DEFAULT '{"lat": 30.12, "lng": 31.62}',
    is_in_compound BOOLEAN DEFAULT FALSE,
    installments_available BOOLEAN DEFAULT FALSE,
    finance_available BOOLEAN DEFAULT FALSE,
    delivery_immediate BOOLEAN DEFAULT TRUE,
    delivery_date DATE,
    installments_info JSONB, -- {downPayment, monthlyInstallment, years}
    listing_status listing_status DEFAULT 'active',
    listing_start_date TIMESTAMPTZ DEFAULT NOW(),
    listing_end_date TIMESTAMPTZ,
    contact_method TEXT DEFAULT 'platform',
    owner_phone TEXT,
    reference_number TEXT,
    slug TEXT,
    source_type TEXT DEFAULT 'partner_direct', -- 'developer', 'broker', 'partner_direct', 'platform_admin', 'direct_owner', 'owner_public'
    publication_status TEXT DEFAULT 'draft', -- 'draft', 'pending_review', 'published', 'rejected', 'archived'
    availability_status TEXT DEFAULT 'available', -- 'available', 'reserved', 'sold'
    verification_status TEXT DEFAULT 'pending', -- 'pending', 'verified', 'rejected'
    is_verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMPTZ,
    last_verified_at TIMESTAMPTZ,
    price_updated_at TIMESTAMPTZ DEFAULT NOW(),
    last_price_confirmed_at TIMESTAMPTZ,
    last_availability_confirmed_at TIMESTAMPTZ,
    created_by UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    updated_by UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    source_request_id UUID REFERENCES public.requests(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Property Audit History
CREATE TABLE IF NOT EXISTS public.property_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID REFERENCES public.properties(id) ON DELETE CASCADE NOT NULL,
    changed_by TEXT NOT NULL,
    change_type TEXT,
    field_name TEXT NOT NULL,
    old_value JSONB,
    new_value JSONB,
    note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Portfolio Items (Finishing partners)
CREATE TABLE IF NOT EXISTS public.portfolio_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL,
    title_en TEXT NOT NULL,
    title_ar TEXT NOT NULL,
    category_en TEXT NOT NULL,
    category_ar TEXT NOT NULL,
    image_url TEXT NOT NULL,
    price NUMERIC,
    dimensions TEXT,
    availability TEXT DEFAULT 'Made to Order',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Decoration Categories
CREATE TABLE IF NOT EXISTS public.decoration_categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_ar TEXT NOT NULL,
    name_en TEXT NOT NULL,
    description_ar TEXT NOT NULL,
    description_en TEXT NOT NULL,
    display_order INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Canonical Finishing Services
CREATE TABLE IF NOT EXISTS public.finishing_services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_en TEXT NOT NULL,
    title_ar TEXT NOT NULL,
    description_en TEXT,
    description_ar TEXT,
    category TEXT DEFAULT 'turnkey', -- turnkey, architectural, consultation, commercial, renovation
    pricing_model TEXT DEFAULT 'per_sqm', -- per_sqm, fixed_package, custom_quote
    base_price NUMERIC DEFAULT 0,
    currency TEXT DEFAULT 'EGP',
    pricing_tiers JSONB DEFAULT '[]'::jsonb,
    features JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    target_partner_id UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Requests (CRM)
CREATE TABLE IF NOT EXISTS public.requests (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type request_type NOT NULL,
    status TEXT DEFAULT 'new',
    requester_name TEXT NOT NULL,
    requester_phone TEXT NOT NULL,
    requester_email TEXT,
    assigned_to UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    payload JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Main: Request Messages (Thread/Timeline)
CREATE TABLE IF NOT EXISTS public.request_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id UUID REFERENCES public.requests(id) ON DELETE CASCADE NOT NULL,
    sender TEXT NOT NULL, -- 'client', 'partner', 'admin', 'system'
    sender_id UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    type TEXT DEFAULT 'message', -- 'message', 'note'
    content TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL,
    message JSONB NOT NULL, -- {ar, en}
    link TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Finance: Transactions
CREATE TABLE IF NOT EXISTS public.transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    user_name TEXT,
    amount NUMERIC NOT NULL,
    currency TEXT DEFAULT 'EGP',
    type TEXT NOT NULL, -- 'subscription_fee', 'listing_fee', etc.
    description TEXT,
    method TEXT NOT NULL, -- 'card', 'instapay', 'wallet'
    status TEXT DEFAULT 'pending',
    reference_number TEXT,
    receipt_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- CMS: Site Content & Configurations
CREATE TABLE IF NOT EXISTS public.site_content (
    key TEXT PRIMARY KEY,
    content JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Finishing: Execution Milestones (P0.1)
CREATE TABLE IF NOT EXISTS public.finishing_milestones (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id UUID REFERENCES public.requests(id) ON DELETE CASCADE NOT NULL,
    stage_number INTEGER NOT NULL,
    title_ar TEXT NOT NULL,
    title_en TEXT NOT NULL,
    description_ar TEXT,
    description_en TEXT,
    target_days INTEGER DEFAULT 15,
    status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'in_progress', 'completed', 'delayed'
    progress_percentage INTEGER NOT NULL DEFAULT 0,
    payment_percentage NUMERIC NOT NULL DEFAULT 0,
    payment_status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'due', 'paid'
    inspector_notes TEXT,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT uq_finishing_request_stage UNIQUE (request_id, stage_number),
    CONSTRAINT chk_milestone_progress CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    CONSTRAINT chk_milestone_payment_pct CHECK (payment_percentage >= 0 AND payment_percentage <= 100)
);

-- Finishing: Partner Service Capabilities & Geographic Coverage
CREATE TABLE IF NOT EXISTS public.partner_capabilities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL UNIQUE,
    categories TEXT[] DEFAULT '{}',
    service_areas TEXT[] DEFAULT '{}',
    min_budget NUMERIC DEFAULT 0,
    max_budget NUMERIC,
    turnkey_capacity INTEGER DEFAULT 5,
    warranty_years INTEGER DEFAULT 2,
    has_in_house_architects BOOLEAN DEFAULT TRUE,
    is_verified_contractor BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Finishing: Quotes & Bids
CREATE TABLE IF NOT EXISTS public.finishing_quotes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id UUID REFERENCES public.requests(id) ON DELETE CASCADE NOT NULL,
    partner_id UUID REFERENCES public.partners(id) ON DELETE CASCADE NOT NULL,
    partner_name TEXT NOT NULL,
    total_price NUMERIC NOT NULL,
    price_per_sqm NUMERIC,
    currency TEXT DEFAULT 'EGP',
    execution_timeline_days INTEGER NOT NULL,
    warranty_months INTEGER DEFAULT 24,
    scope_items JSONB DEFAULT '[]'::jsonb,
    terms_and_conditions TEXT,
    status TEXT DEFAULT 'submitted', -- 'draft', 'submitted', 'under_review', 'accepted', 'rejected'
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Finishing: Request History & Audit Trail
CREATE TABLE IF NOT EXISTS public.finishing_request_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id UUID REFERENCES public.requests(id) ON DELETE CASCADE NOT NULL,
    action_type TEXT NOT NULL, -- 'created', 'status_change', 'partner_assigned', 'quote_submitted', 'quote_accepted', 'quote_rejected', 'site_visit_scheduled', 'note_added'
    changed_by TEXT NOT NULL,
    old_value JSONB,
    new_value JSONB,
    note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. INDEXES
CREATE INDEX IF NOT EXISTS idx_properties_partner ON public.properties(partner_id);
CREATE INDEX IF NOT EXISTS idx_properties_listing_status ON public.properties(listing_status);
CREATE INDEX IF NOT EXISTS idx_properties_source_request ON public.properties(source_request_id);
CREATE INDEX IF NOT EXISTS idx_properties_reference ON public.properties(reference_number);
CREATE INDEX IF NOT EXISTS idx_properties_slug ON public.properties(slug);
CREATE INDEX IF NOT EXISTS idx_property_history_prop ON public.property_history(property_id);
CREATE INDEX IF NOT EXISTS idx_finishing_services_active ON public.finishing_services(is_active, display_order);
CREATE INDEX IF NOT EXISTS idx_partner_capabilities_partner ON public.partner_capabilities(partner_id);
CREATE INDEX IF NOT EXISTS idx_finishing_quotes_req ON public.finishing_quotes(request_id);
CREATE INDEX IF NOT EXISTS idx_finishing_quotes_partner ON public.finishing_quotes(partner_id);
CREATE INDEX IF NOT EXISTS idx_finishing_req_hist_req ON public.finishing_request_history(request_id);
CREATE INDEX IF NOT EXISTS idx_finishing_milestones_req ON public.finishing_milestones(request_id);
CREATE INDEX IF NOT EXISTS idx_requests_assigned ON public.requests(assigned_to);
CREATE INDEX IF NOT EXISTS idx_requests_type ON public.requests(type);
CREATE INDEX IF NOT EXISTS idx_requests_status ON public.requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_created_at ON public.requests(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_requests_requester_email ON public.requests(requester_email);
CREATE INDEX IF NOT EXISTS idx_requests_type_created ON public.requests(type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_request_messages_req ON public.request_messages(request_id);
CREATE INDEX IF NOT EXISTS idx_request_history_req ON public.request_history(request_id);
CREATE INDEX IF NOT EXISTS idx_request_history_created ON public.request_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON public.notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON public.transactions(user_id);

-- P0.4: Database View for Masked Partner Leads (PII Protection)
CREATE OR REPLACE VIEW public.partner_leads_view AS
SELECT 
    r.id,
    r.type,
    r.status,
    CASE 
        WHEN r.assigned_to = auth.uid() 
             OR (r.payload->>'partnerId')::uuid = auth.uid() 
             OR EXISTS (
                 SELECT 1 FROM public.finishing_quotes fq 
                 WHERE fq.request_id = r.id AND fq.partner_id = auth.uid() AND fq.status = 'accepted'
             ) 
             OR EXISTS (
                 SELECT 1 FROM public.partners p 
                 WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role LIKE '%_manager')
             )
        THEN r.requester_name
        ELSE 'عميل المنصة (مناقصة)'
    END AS requester_name,
    CASE 
        WHEN r.assigned_to = auth.uid() 
             OR (r.payload->>'partnerId')::uuid = auth.uid() 
             OR EXISTS (
                 SELECT 1 FROM public.finishing_quotes fq 
                 WHERE fq.request_id = r.id AND fq.partner_id = auth.uid() AND fq.status = 'accepted'
             ) 
             OR EXISTS (
                 SELECT 1 FROM public.partners p 
                 WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role LIKE '%_manager')
             )
        THEN r.requester_phone
        ELSE NULL
    END AS requester_phone,
    CASE 
        WHEN r.assigned_to = auth.uid() 
             OR (r.payload->>'partnerId')::uuid = auth.uid() 
             OR EXISTS (
                 SELECT 1 FROM public.finishing_quotes fq 
                 WHERE fq.request_id = r.id AND fq.partner_id = auth.uid() AND fq.status = 'accepted'
             ) 
             OR EXISTS (
                 SELECT 1 FROM public.partners p 
                 WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role LIKE '%_manager')
             )
        THEN r.requester_email
        ELSE NULL
    END AS requester_email,
    r.assigned_to,
    CASE 
        WHEN r.assigned_to = auth.uid() 
             OR (r.payload->>'partnerId')::uuid = auth.uid() 
             OR EXISTS (
                 SELECT 1 FROM public.finishing_quotes fq 
                 WHERE fq.request_id = r.id AND fq.partner_id = auth.uid() AND fq.status = 'accepted'
             ) 
             OR EXISTS (
                 SELECT 1 FROM public.partners p 
                 WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role LIKE '%_manager')
             )
        THEN r.payload
        ELSE (r.payload - 'customerPhone' - 'customerName')
    END AS payload,
    r.created_at,
    r.updated_at
FROM public.requests r;


-- P1.1: Single accepted quote constraint per finishing request
CREATE UNIQUE INDEX IF NOT EXISTS uq_finishing_quotes_single_accepted 
ON public.finishing_quotes (request_id) 
WHERE status = 'accepted';

-- P1.2: Lock awarded quotes against modifications
CREATE OR REPLACE FUNCTION trg_prevent_accepted_quote_modification()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.status = 'accepted' THEN
        IF (NEW.total_price <> OLD.total_price OR 
            NEW.scope_items <> OLD.scope_items OR
            NEW.execution_timeline_days <> OLD.execution_timeline_days OR
            NEW.warranty_months <> OLD.warranty_months) THEN
            RAISE EXCEPTION 'Commercial terms on an accepted quote are permanently locked and cannot be modified.';
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS check_accepted_quote_immutable ON public.finishing_quotes;
CREATE TRIGGER check_accepted_quote_immutable
BEFORE UPDATE ON public.finishing_quotes
FOR EACH ROW EXECUTE PROCEDURE trg_prevent_accepted_quote_modification();

-- 5. RLS POLICIES

-- Partners
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public profiles are viewable by everyone" ON public.partners FOR SELECT USING (status = 'active');
CREATE POLICY "Users can update their own profile" ON public.partners FOR UPDATE USING (auth.uid() = id);

-- Partner Capabilities
ALTER TABLE public.partner_capabilities ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can view partner capabilities" ON public.partner_capabilities FOR SELECT USING (true);
CREATE POLICY "Partners update own capabilities" ON public.partner_capabilities FOR ALL USING (auth.uid() = partner_id);
CREATE POLICY "Admins manage all partner capabilities" ON public.partner_capabilities FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND (role = 'super_admin' OR role = 'platform_finishing_manager' OR role = 'finishing_market_manager'))
);

-- Properties
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public properties are viewable by everyone" ON public.properties FOR SELECT USING (listing_status IN ('active', 'sold'));
CREATE POLICY "Partners manage their own properties" ON public.properties FOR ALL USING (auth.uid() = partner_id);
CREATE POLICY "Admins manage all properties" ON public.properties FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND role = 'super_admin')
);

-- Property History
ALTER TABLE public.property_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view all property history" ON public.property_history FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Partners view own property history" ON public.property_history FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.properties WHERE id = property_history.property_id AND partner_id = auth.uid())
);
CREATE POLICY "Authenticated users record property history" ON public.property_history FOR INSERT WITH CHECK (true);

-- Finishing Services
ALTER TABLE public.finishing_services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public finishing services are viewable by everyone" ON public.finishing_services FOR SELECT USING (is_active = true);
CREATE POLICY "Admins and managers manage finishing services" ON public.finishing_services FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND (role = 'super_admin' OR role = 'platform_finishing_manager' OR role = 'finishing_market_manager'))
);

-- Finishing Quotes (P0.2 & P1.2 Hardening)
ALTER TABLE public.finishing_quotes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers view quotes for own requests" ON public.finishing_quotes FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests 
        WHERE requests.id = finishing_quotes.request_id 
        AND (
            requests.requester_email = auth.jwt()->>'email'
            OR (requests.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
);
CREATE POLICY "Partners view own quotes" ON public.finishing_quotes FOR SELECT USING (auth.uid() = partner_id);
CREATE POLICY "Partners insert own quotes" ON public.finishing_quotes FOR INSERT WITH CHECK (auth.uid() = partner_id);
CREATE POLICY "Partners update own non_accepted quotes" ON public.finishing_quotes FOR UPDATE USING (auth.uid() = partner_id AND status != 'accepted');
CREATE POLICY "Partners delete own non_accepted quotes" ON public.finishing_quotes FOR DELETE USING (auth.uid() = partner_id AND status != 'accepted');
CREATE POLICY "Admins view and manage all finishing quotes" ON public.finishing_quotes FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND (role = 'super_admin' OR role = 'platform_finishing_manager' OR role = 'finishing_market_manager'))
);

-- Finishing Request History
ALTER TABLE public.finishing_request_history ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins view all finishing request history" ON public.finishing_request_history FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND (role = 'super_admin' OR role = 'platform_finishing_manager' OR role = 'finishing_market_manager'))
);
CREATE POLICY "Partners view history of assigned requests" ON public.finishing_request_history FOR SELECT USING (
    EXISTS (SELECT 1 FROM public.requests WHERE id = finishing_request_history.request_id AND assigned_to = auth.uid())
);
CREATE POLICY "Customers view history of own requests" ON public.finishing_request_history FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests 
        WHERE requests.id = finishing_request_history.request_id 
        AND (
            requests.requester_email = auth.jwt()->>'email'
            OR (requests.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
);
CREATE POLICY "Authenticated users insert finishing request history" ON public.finishing_request_history FOR INSERT WITH CHECK (true);

-- Finishing Milestones (P0.1 & Milestone Auth)
ALTER TABLE public.finishing_milestones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers view milestones for own requests" ON public.finishing_milestones FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests 
        WHERE requests.id = finishing_milestones.request_id 
        AND (
            requests.requester_email = auth.jwt()->>'email'
            OR (requests.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
);
CREATE POLICY "Assigned partners view own project milestones" ON public.finishing_milestones FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests 
        WHERE requests.id = finishing_milestones.request_id 
        AND (requests.assigned_to = auth.uid() OR (requests.payload->>'partnerId')::uuid = auth.uid())
    )
);
CREATE POLICY "Assigned partners update own project milestones" ON public.finishing_milestones FOR UPDATE USING (
    EXISTS (
        SELECT 1 FROM public.requests 
        WHERE requests.id = finishing_milestones.request_id 
        AND (requests.assigned_to = auth.uid() OR (requests.payload->>'partnerId')::uuid = auth.uid())
    )
);
CREATE POLICY "Admins manage all finishing milestones" ON public.finishing_milestones FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners WHERE id = auth.uid() AND (role = 'super_admin' OR role = 'platform_finishing_manager' OR role = 'finishing_market_manager'))
);

-- Portfolio Items (Decorations & Finishing)
ALTER TABLE public.portfolio_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public view portfolio items" ON public.portfolio_items FOR SELECT USING (true);
CREATE POLICY "Partners and admins insert portfolio items" ON public.portfolio_items FOR INSERT WITH CHECK (
    partner_id = auth.uid() OR EXISTS (SELECT 1 FROM public.partners p WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role IN ('decoration_manager', 'platform_finishing_manager')))
);
CREATE POLICY "Partners and admins update portfolio items" ON public.portfolio_items FOR UPDATE USING (
    partner_id = auth.uid() OR EXISTS (SELECT 1 FROM public.partners p WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role IN ('decoration_manager', 'platform_finishing_manager')))
);
CREATE POLICY "Partners and admins delete portfolio items" ON public.portfolio_items FOR DELETE USING (
    partner_id = auth.uid() OR EXISTS (SELECT 1 FROM public.partners p WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role IN ('decoration_manager', 'platform_finishing_manager')))
);

-- Decoration Categories
ALTER TABLE public.decoration_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public view decoration categories" ON public.decoration_categories FOR SELECT USING (true);
CREATE POLICY "Admins and decoration managers manage decoration categories" ON public.decoration_categories FOR ALL USING (
    EXISTS (SELECT 1 FROM public.partners p WHERE p.id = auth.uid() AND (p.role = 'super_admin' OR p.role = 'decoration_manager'))
);

-- Requests (P0.2 & P0.3 Hardened)
ALTER TABLE public.requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can create a request or inquiry" ON public.requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Customers view their own requests" ON public.requests FOR SELECT USING (
    requester_email = auth.jwt()->>'email' OR (payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
);
CREATE POLICY "Assigned partners can view their requests" ON public.requests FOR SELECT USING (
    auth.uid() = assigned_to OR (payload->>'partnerId')::uuid = auth.uid()
);
CREATE POLICY "Assigned partners can update their requests" ON public.requests FOR UPDATE USING (
    auth.uid() = assigned_to OR (payload->>'partnerId')::uuid = auth.uid()
) WITH CHECK (
    auth.uid() = assigned_to OR (payload->>'partnerId')::uuid = auth.uid()
);
CREATE POLICY "Admins and managers manage requests" ON public.requests FOR ALL USING (
    EXISTS (
        SELECT 1 FROM public.partners p 
        WHERE p.id = auth.uid() 
        AND (
            p.role = 'super_admin'
            OR (p.role IN ('platform_finishing_manager', 'finishing_market_manager') AND (
                requests.type = 'LEAD' AND (
                    requests.payload->>'serviceType' IN ('finishing', 'renovation', 'turnkey')
                    OR requests.payload->>'category' = 'turnkey'
                    OR requests.payload->>'serviceTitle' ILIKE '%تشطيب%'
                    OR requests.payload->>'serviceTitle' ILIKE '%finishing%'
                )
                OR requests.assigned_to = auth.uid()
            ))
            OR (p.role = 'decoration_manager' AND (
                requests.type = 'LEAD' AND (
                    requests.payload->>'serviceType' IN ('decorations', 'decoration')
                    OR requests.payload->>'serviceTitle' ILIKE '%ديكور%'
                    OR requests.payload->>'serviceTitle' ILIKE '%decor%'
                )
                OR requests.assigned_to = auth.uid()
            ))
            OR (p.role IN ('listings_manager', 'platform_real_estate_manager', 'real_estate_market_manager') AND (
                requests.type IN ('PROPERTY_LISTING_REQUEST', 'PROPERTY_INQUIRY')
                OR (requests.type = 'LEAD' AND (requests.payload->>'serviceType' = 'property' OR requests.payload->>'propertyId' IS NOT NULL))
                OR requests.assigned_to = auth.uid()
            ))
            OR (p.role = 'partner_relations_manager' AND (
                requests.type = 'PARTNER_APPLICATION'
                OR requests.assigned_to = auth.uid()
            ))
            OR (p.role IN ('customer_relations_manager', 'service_manager') AND (
                requests.type IN ('CONTACT_MESSAGE', 'PROPERTY_INQUIRY')
                OR requests.assigned_to = auth.uid()
            ))
        )
    )
);

-- Request Messages (P0.1 RLS Hardened)
ALTER TABLE public.request_messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers view messages for own requests" ON public.request_messages FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_messages.request_id 
        AND (
            r.requester_email = auth.jwt()->>'email'
            OR (r.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
    AND request_messages.type = 'message'
);
CREATE POLICY "Customers insert messages for own requests" ON public.request_messages FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_messages.request_id 
        AND (
            r.requester_email = auth.jwt()->>'email'
            OR (r.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
    AND request_messages.sender = 'client'
    AND request_messages.type = 'message'
);
CREATE POLICY "Assigned partners view messages for assigned requests" ON public.request_messages FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_messages.request_id 
        AND (r.assigned_to = auth.uid() OR (r.payload->>'partnerId')::uuid = auth.uid())
    )
);
CREATE POLICY "Assigned partners insert messages for assigned requests" ON public.request_messages FOR INSERT WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_messages.request_id 
        AND (r.assigned_to = auth.uid() OR (r.payload->>'partnerId')::uuid = auth.uid())
    )
    AND request_messages.sender = 'partner'
);
CREATE POLICY "Admins and managers view and insert all request messages" ON public.request_messages FOR ALL USING (
    EXISTS (
        SELECT 1 FROM public.partners p 
        WHERE p.id = auth.uid() 
        AND (
            p.role IN (
                'super_admin', 'platform_finishing_manager', 'finishing_market_manager',
                'decoration_manager', 'listings_manager', 'platform_real_estate_manager',
                'real_estate_market_manager', 'partner_relations_manager',
                'customer_relations_manager', 'service_manager'
            )
        )
    )
);

-- Notifications (RLS Hardened)
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own notifications" ON public.notifications FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE USING (user_id = auth.uid());
CREATE POLICY "Authenticated users create notifications" ON public.notifications FOR INSERT WITH CHECK (true);

-- General Request History (P1.1 Audit Trail)
CREATE TABLE IF NOT EXISTS public.request_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_id UUID REFERENCES public.requests(id) ON DELETE CASCADE NOT NULL,
    actor_id UUID REFERENCES public.partners(id) ON DELETE SET NULL,
    actor_name TEXT NOT NULL DEFAULT 'System',
    actor_role TEXT,
    action TEXT NOT NULL,
    old_status TEXT,
    new_status TEXT,
    old_assigned_to UUID,
    new_assigned_to UUID,
    metadata JSONB DEFAULT '{}'::jsonb,
    note TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.request_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and managers view scoped request history" ON public.request_history FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.partners p 
        WHERE p.id = auth.uid() 
        AND (
            p.role = 'super_admin'
            OR (p.role IN ('platform_finishing_manager', 'finishing_market_manager') AND EXISTS (
                SELECT 1 FROM public.requests r 
                WHERE r.id = request_history.request_id 
                AND (
                    (r.type = 'LEAD' AND (
                        r.payload->>'serviceType' IN ('finishing', 'renovation', 'turnkey')
                        OR r.payload->>'category' = 'turnkey'
                        OR r.payload->>'serviceTitle' ILIKE '%تشطيب%'
                        OR r.payload->>'serviceTitle' ILIKE '%finishing%'
                    ))
                    OR r.assigned_to = auth.uid()
                )
            ))
            OR (p.role = 'decoration_manager' AND EXISTS (
                SELECT 1 FROM public.requests r 
                WHERE r.id = request_history.request_id 
                AND (
                    (r.type = 'LEAD' AND (
                        r.payload->>'serviceType' IN ('decorations', 'decoration')
                        OR r.payload->>'serviceTitle' ILIKE '%ديكور%'
                        OR r.payload->>'serviceTitle' ILIKE '%decor%'
                    ))
                    OR r.assigned_to = auth.uid()
                )
            ))
            OR (p.role IN ('listings_manager', 'platform_real_estate_manager', 'real_estate_market_manager') AND EXISTS (
                SELECT 1 FROM public.requests r 
                WHERE r.id = request_history.request_id 
                AND (
                    r.type IN ('PROPERTY_LISTING_REQUEST', 'PROPERTY_INQUIRY')
                    OR (r.type = 'LEAD' AND (r.payload->>'serviceType' = 'property' OR r.payload->>'propertyId' IS NOT NULL))
                    OR r.assigned_to = auth.uid()
                )
            ))
            OR (p.role = 'partner_relations_manager' AND EXISTS (
                SELECT 1 FROM public.requests r 
                WHERE r.id = request_history.request_id 
                AND (
                    r.type = 'PARTNER_APPLICATION'
                    OR r.assigned_to = auth.uid()
                )
            ))
            OR (p.role IN ('customer_relations_manager', 'service_manager') AND EXISTS (
                SELECT 1 FROM public.requests r 
                WHERE r.id = request_history.request_id 
                AND (
                    r.type IN ('CONTACT_MESSAGE', 'PROPERTY_INQUIRY')
                    OR r.assigned_to = auth.uid()
                )
            ))
        )
    )
);

CREATE POLICY "Assigned partners view history of assigned requests" ON public.request_history FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_history.request_id 
        AND (r.assigned_to = auth.uid() OR (r.payload->>'partnerId')::uuid = auth.uid())
    )
);

CREATE POLICY "Customers view history of own requests" ON public.request_history FOR SELECT USING (
    EXISTS (
        SELECT 1 FROM public.requests r 
        WHERE r.id = request_history.request_id 
        AND (
            r.requester_email = auth.jwt()->>'email'
            OR (r.payload->'requesterInfo'->>'email') = auth.jwt()->>'email'
        )
    )
);

-- 6. ATOMIC QUOTE AWARD RPC FUNCTION (P0.3)
CREATE OR REPLACE FUNCTION public.accept_finishing_quote(
    p_quote_id UUID,
    p_request_id UUID,
    p_client_name TEXT DEFAULT 'العميل'
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_quote RECORD;
    v_request RECORD;
    v_now TIMESTAMPTZ := NOW();
BEGIN
    -- 1. Lock and fetch the request
    SELECT * INTO v_request 
    FROM public.requests 
    WHERE id = p_request_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Request not found: %', p_request_id;
    END IF;

    -- 2. Authorization check
    IF NOT (
        v_request.requester_email = auth.jwt()->>'email' OR 
        (v_request.payload->'requesterInfo'->>'email') = auth.jwt()->>'email' OR
        EXISTS (
            SELECT 1 FROM public.partners 
            WHERE id = auth.uid() 
            AND (role = 'super_admin' OR role = 'platform_finishing_manager')
        )
    ) THEN
        RAISE EXCEPTION 'Not authorized to award quote for this request.';
    END IF;

    -- 3. Lock and fetch the target quote
    SELECT * INTO v_quote 
    FROM public.finishing_quotes 
    WHERE id = p_quote_id AND request_id = p_request_id 
    FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Quote not found or does not belong to request.';
    END IF;

    IF v_quote.status = 'rejected' THEN
        RAISE EXCEPTION 'Cannot accept a previously rejected quote.';
    END IF;

    -- 4. Mark winning quote as accepted
    UPDATE public.finishing_quotes 
    SET status = 'accepted', updated_at = v_now 
    WHERE id = p_quote_id;

    -- 5. Atomically reject all other quotes for this request
    UPDATE public.finishing_quotes 
    SET status = 'rejected', updated_at = v_now 
    WHERE request_id = p_request_id AND id <> p_quote_id;

    -- 6. Update Request to in-progress and assign winning contractor
    UPDATE public.requests 
    SET status = 'in-progress',
        assigned_to = v_quote.partner_id,
        payload = jsonb_set(
            jsonb_set(COALESCE(payload, '{}'::jsonb), '{partnerId}', to_jsonb(v_quote.partner_id::text)),
            '{awardedQuoteId}', to_jsonb(p_quote_id::text)
        ),
        updated_at = v_now 
    WHERE id = p_request_id;

    -- 7. Seed default 5 milestones in database if none exist yet for this request
    IF NOT EXISTS (SELECT 1 FROM public.finishing_milestones WHERE request_id = p_request_id) THEN
        INSERT INTO public.finishing_milestones (
            request_id, stage_number, title_ar, title_en, description_ar, description_en, 
            target_days, status, progress_percentage, payment_percentage, payment_status, created_at, updated_at
        ) VALUES 
        (p_request_id, 1, 'المخططات التنفيذية واعتماد التصميم 3D', 'Architectural & Executive MEP Blueprints', 'إعداد المخططات التنفيذية، رسومات 3D وتوزيع نقاط الكهرباء والسباكة واعتماد لوحة العينات.', 15, 'in_progress', 0, 10, 'pending', v_now, v_now),
        (p_request_id, 2, 'تأسيس الكهرباء والسباكة والعزل المائي', 'MEP Rough-ins, Electrical & Plumbing Lines', 'تكسير وتمديد مواسير التغذية والصرف، علب الكهرباء، وتطبيق طبقات العزل المائي واختباره هندسياً.', 25, 'pending', 0, 30, 'pending', v_now, v_now),
        (p_request_id, 3, 'المحارة والجبس بورد وأوتار الأرضيات', 'Plastering, Thermal/Waterproofing & Screed', 'تثبيت الشبك المعدني، الطرطشة والبؤج والأوتار، أعمال المحارة وتأسيس أسقف الجبس بورد.', 20, 'pending', 0, 20, 'pending', v_now, v_now),
        (p_request_id, 4, 'الأرضيات والدهانات وتركيب الأطقم والتشطيب', 'Flooring, Paint, Ceiling & Fixtures', 'تركيب البورسلين والسيراميك، تشطيب الدهانات، تركيب المفاتيح والإنارة والأطقم الصحية والأبواب.', 30, 'pending', 0, 30, 'pending', v_now, v_now),
        (p_request_id, 5, 'المراجعة الفنية وجدول الملاحظات وتسليم المفتاح', 'Final Audit, Snagging List & Key Handover', 'فحص الجودة والمطابقة الهندسية الشاملة، استكمال بنود الملاحظات (Snagging list) وتسليم العميل.', 10, 'pending', 0, 10, 'pending', v_now, v_now);
    END IF;

    -- 8. Record history event in finishing_request_history
    INSERT INTO public.finishing_request_history (
        request_id, action_type, changed_by, new_value, note, created_at
    ) VALUES (
        p_request_id,
        'quote_accepted',
        p_client_name,
        jsonb_build_object(
            'quoteId', p_quote_id,
            'partnerId', v_quote.partner_id,
            'partnerName', v_quote.partner_name,
            'totalPrice', v_quote.total_price,
            'timelineDays', v_quote.execution_timeline_days
        ),
        'تم اعتماد وترسية المقايسة المقدمة من (' || v_quote.partner_name || ') بمبلغ ' || v_quote.total_price || ' ' || COALESCE(v_quote.currency, 'EGP') || ' والبدء في تنفيذ المشروع.',
        v_now
    );

    RETURN jsonb_build_object(
        'success', true,
        'requestId', p_request_id,
        'awardedQuoteId', p_quote_id,
        'partnerId', v_quote.partner_id,
        'partnerName', v_quote.partner_name,
        'totalPrice', v_quote.total_price
    );
END;
$$;

-- 7. TRIGGERS FOR TIMESTAMPS
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_partners_updated_at BEFORE UPDATE ON public.partners FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_properties_updated_at BEFORE UPDATE ON public.properties FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_requests_updated_at BEFORE UPDATE ON public.requests FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_finishing_services_updated_at BEFORE UPDATE ON public.finishing_services FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_partner_capabilities_updated_at BEFORE UPDATE ON public.partner_capabilities FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_finishing_quotes_updated_at BEFORE UPDATE ON public.finishing_quotes FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();
CREATE TRIGGER update_finishing_milestones_updated_at BEFORE UPDATE ON public.finishing_milestones FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- P1.1: Automatic Request Mutation Audit Logging Trigger
CREATE OR REPLACE FUNCTION trg_log_request_mutation()
RETURNS TRIGGER AS $$
DECLARE
    v_actor_id UUID := auth.uid();
    v_actor_name TEXT := 'System';
    v_actor_role TEXT := 'system';
BEGIN
    IF v_actor_id IS NOT NULL THEN
        SELECT name_en, role INTO v_actor_name, v_actor_role FROM public.partners WHERE id = v_actor_id;
        IF v_actor_name IS NULL THEN
            v_actor_name := COALESCE(auth.jwt()->>'email', 'Authenticated User');
        END IF;
    END IF;

    IF (TG_OP = 'INSERT') THEN
        INSERT INTO public.request_history (
            request_id, actor_id, actor_name, actor_role, action,
            new_status, new_assigned_to, metadata, note, created_at
        ) VALUES (
            NEW.id, v_actor_id, v_actor_name, v_actor_role, 'created',
            NEW.status, NEW.assigned_to, jsonb_build_object('type', NEW.type),
            'تم إنشاء الطلب في النظام', NOW()
        );
    ELSIF (TG_OP = 'UPDATE') THEN
        IF (OLD.status IS DISTINCT FROM NEW.status OR OLD.assigned_to IS DISTINCT FROM NEW.assigned_to) THEN
            INSERT INTO public.request_history (
                request_id, actor_id, actor_name, actor_role,
                action, old_status, new_status, old_assigned_to, new_assigned_to,
                metadata, note, created_at
            ) VALUES (
                NEW.id, v_actor_id, v_actor_name, v_actor_role,
                CASE 
                    WHEN OLD.assigned_to IS DISTINCT FROM NEW.assigned_to THEN 'reassigned'
                    ELSE 'status_changed'
                END,
                OLD.status, NEW.status, OLD.assigned_to, NEW.assigned_to,
                jsonb_build_object('type', NEW.type),
                CASE 
                    WHEN OLD.assigned_to IS DISTINCT FROM NEW.assigned_to THEN 'تمت إعادة تعيين مسؤول الطلب'
                    ELSE 'تحديث حالة الطلب إلى: ' || NEW.status
                END,
                NOW()
            );
        END IF;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public, pg_temp;

DROP TRIGGER IF EXISTS log_request_mutation_trigger ON public.requests;
CREATE TRIGGER log_request_mutation_trigger
AFTER INSERT OR UPDATE ON public.requests
FOR EACH ROW EXECUTE PROCEDURE trg_log_request_mutation();


